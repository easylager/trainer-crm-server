from __future__ import annotations

import time
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from enum import StrEnum
from typing import Generic, ParamSpec, TypeAlias, TypeVar

from relprim.circuit_breaker import CircuitBreaker
from relprim.errors import (
    CircuitBreakerOpenError,
    FallbackChainError,
    OperationExecutionError,
    OperationTimeoutError,
    RetryAfterExtractionError,
    ValidationFailedError,
)
from relprim.events import EventEmitter, EventType
from relprim.fallback import FallbackChain, FallbackResult
from relprim.idempotency import IdempotencyPolicy, IdempotencyResult
from relprim.rate_limit import RateLimitDecision, RateLimitPolicy
from relprim.report import (
    AttemptStatus,
    ExecutionAttempt,
    ExecutionError,
    ExecutionReport,
    ExecutionStatus,
)
from relprim.result import OperationResult
from relprim.retry import RetryPolicy
from relprim.timeout import TimeoutPolicy
from relprim.validation import ValidationPolicy, ValidationResult

P = ParamSpec("P")
R = TypeVar("R")

MetadataValue: TypeAlias = str | int | float | bool | None
Metadata: TypeAlias = Mapping[str, MetadataValue]
MutableMetadata: TypeAlias = dict[str, MetadataValue]


class _RetryDelaySource(StrEnum):
    BACKOFF = "backoff"
    PROVIDER = "provider"


@dataclass(frozen=True, slots=True)
class _RetryPlan:
    retryable: bool
    rate_limited: bool = False
    retry_after_seconds: float | None = None
    delay_seconds: float | None = None
    delay_source: _RetryDelaySource | None = None
    max_wait_exceeded: bool = False

    def __post_init__(self) -> None:
        if self.retryable:
            if self.delay_seconds is None or self.delay_source is None:
                raise ValueError("retryable plans must include delay information.")
        elif self.delay_seconds is not None or self.delay_source is not None:
            raise ValueError("non-retryable plans must not include a retry delay.")

        if self.max_wait_exceeded and not self.rate_limited:
            raise ValueError("max_wait_exceeded requires a rate-limited plan.")


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _elapsed_seconds(started_at: float) -> float:
    return time.perf_counter() - started_at


@dataclass(frozen=True, slots=True)
class AsyncOperation(Generic[P, R]):
    """Composable resilient execution wrapper for asynchronous operations.

    AsyncOperation is the first higher-level RelPrim API. It composes low-level
    primitives such as retry, timeout, circuit breaker, fallback and validation
    policies, while returning an OperationResult that contains both the business
    value and an execution report.

    This class intentionally does not know anything about AI providers, HTTP,
    payments, queues or storage. It operates on any async callable.
    """

    name: str
    _operation: Callable[P, Awaitable[R]]
    _retry_policy: RetryPolicy | None = None
    _timeout_policy: TimeoutPolicy | None = None
    _fallback_chain: FallbackChain[P, R] | None = None
    _circuit_breaker: CircuitBreaker | None = None
    _validation_policy: ValidationPolicy[R] | None = None
    _event_emitter: EventEmitter | None = None
    _idempotency_policy: IdempotencyPolicy[P] | None = None
    _rate_limit_policy: RateLimitPolicy | None = None

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise ValueError("name must not be empty.")

    def with_retry(self, policy: RetryPolicy) -> AsyncOperation[P, R]:
        """Return a new operation configured with a retry policy."""
        return replace(self, _retry_policy=policy)

    def with_timeout(self, policy: TimeoutPolicy) -> AsyncOperation[P, R]:
        """Return a new operation configured with a timeout policy."""
        return replace(self, _timeout_policy=policy)

    def with_fallbacks(self, chain: FallbackChain[P, R]) -> AsyncOperation[P, R]:
        """Return a new operation configured with fallback candidates."""
        return replace(self, _fallback_chain=chain)

    def with_circuit_breaker(self, breaker: CircuitBreaker) -> AsyncOperation[P, R]:
        """Return a new operation configured with a circuit breaker."""
        return replace(self, _circuit_breaker=breaker)

    def with_validation(self, policy: ValidationPolicy[R]) -> AsyncOperation[P, R]:
        """Return a new operation configured with result validation."""
        return replace(self, _validation_policy=policy)

    def with_events(self, emitter: EventEmitter) -> AsyncOperation[P, R]:
        """Return a new operation configured with a structured event emitter."""
        return replace(self, _event_emitter=emitter)

    def with_idempotency(self, policy: IdempotencyPolicy[P]) -> AsyncOperation[P, R]:
        """Return a new operation configured with idempotent execution."""
        return replace(self, _idempotency_policy=policy)

    def with_rate_limit(self, policy: RateLimitPolicy) -> AsyncOperation[P, R]:
        """Return a new operation configured with rate-limit handling."""
        return replace(self, _rate_limit_policy=policy)

    async def run(self, *args: P.args, **kwargs: P.kwargs) -> OperationResult[R]:
        """Run the operation and return its value with an execution report.

        When idempotency is configured, the entire operation lifecycle is
        coordinated under one idempotency key. This includes retries, timeouts,
        validation, circuit breaker checks and fallback execution.
        """
        if self._idempotency_policy is None:
            return await self._run_without_idempotency(*args, **kwargs)

        idempotency_result = await self._idempotency_policy.run(
            self._run_without_idempotency,
            *args,
            **kwargs,
        )

        return self._operation_result_with_idempotency_metadata(idempotency_result)

    async def _run_without_idempotency(
        self,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> OperationResult[R]:
        """Run the operation and return its value with an execution report.

        Success returns OperationResult[T].

        Failure raises OperationExecutionError with the final ExecutionReport
        attached. This keeps the default failure mode safe: callers cannot
        accidentally ignore failed operations by forgetting to inspect a status.
        """
        operation_started_at = _utc_now()
        operation_started_monotonic = time.perf_counter()
        attempts: list[ExecutionAttempt] = []
        rate_limit_encountered = False
        rate_limit_wait_seconds = 0.0
        rate_limit_wait_exceeded = False

        await self._emit_event(
            EventType.OPERATION_STARTED,
            payload={
                "retry_enabled": self._retry_policy is not None,
                "timeout_enabled": self._timeout_policy is not None,
                "fallback_enabled": self._fallback_chain is not None,
                "circuit_breaker_enabled": self._circuit_breaker is not None,
                "validation_enabled": self._validation_policy is not None,
                "rate_limit_enabled": self._rate_limit_policy is not None,
            },
        )

        max_attempts = self._retry_policy.max_attempts if self._retry_policy is not None else 1

        for attempt_number in range(1, max_attempts + 1):
            attempt_started_at = _utc_now()
            attempt_started_monotonic = time.perf_counter()

            await self._emit_event(
                EventType.ATTEMPT_STARTED,
                payload={
                    "attempt_number": attempt_number,
                    "max_attempts": max_attempts,
                },
            )

            try:
                value, validation_metadata = await self._run_single_attempt(*args, **kwargs)
            except Exception as exc:
                try:
                    retry_plan = self._retry_plan_for_exception(
                        exc,
                        attempt_number=attempt_number,
                    )
                except RetryAfterExtractionError as extraction_error:
                    exc = extraction_error
                    retry_plan = _RetryPlan(retryable=False)

                attempt_status = self._attempt_status_for_exception(exc)
                retryable = retry_plan.retryable

                if retry_plan.rate_limited:
                    rate_limit_encountered = True
                    rate_limit_wait_exceeded = (
                        rate_limit_wait_exceeded or retry_plan.max_wait_exceeded
                    )

                    await self._emit_event(
                        EventType.RATE_LIMIT_DETECTED,
                        payload={
                            "attempt_number": attempt_number,
                            "error_type": exc.__class__.__name__,
                            "retry_after_seconds": retry_plan.retry_after_seconds,
                            "max_wait_seconds": (
                                self._rate_limit_policy.max_wait_seconds
                                if self._rate_limit_policy is not None
                                else None
                            ),
                            "max_wait_exceeded": retry_plan.max_wait_exceeded,
                        },
                    )

                    if retry_plan.max_wait_exceeded:
                        await self._emit_event(
                            EventType.RATE_LIMIT_WAIT_EXCEEDED,
                            payload={
                                "attempt_number": attempt_number,
                                "retry_after_seconds": retry_plan.retry_after_seconds,
                                "delay_seconds": retry_plan.delay_seconds,
                                "max_wait_seconds": (
                                    self._rate_limit_policy.max_wait_seconds
                                    if self._rate_limit_policy is not None
                                    else None
                                ),
                            },
                        )

                attempt_duration = _elapsed_seconds(attempt_started_monotonic)
                failure_metadata = self._primary_failure_metadata(
                    exc,
                    retry_plan=retry_plan,
                )

                if isinstance(exc, ValidationFailedError):
                    await self._emit_event(
                        EventType.VALIDATION_FAILED,
                        payload={
                            "attempt_number": attempt_number,
                            "validator_name": exc.validator_name,
                            "reason": exc.reason,
                        },
                    )

                if isinstance(exc, CircuitBreakerOpenError):
                    await self._emit_event(
                        EventType.CIRCUIT_BREAKER_REJECTED,
                        payload={
                            "attempt_number": attempt_number,
                            "breaker_name": exc.breaker_name,
                            "state": exc.state,
                            "retry_after_seconds": exc.retry_after_seconds,
                        },
                    )

                attempts.append(
                    ExecutionAttempt(
                        attempt_number=attempt_number,
                        status=attempt_status,
                        started_at=attempt_started_at,
                        duration_seconds=attempt_duration,
                        error=ExecutionError.from_exception(exc, retryable=retryable),
                        metadata=failure_metadata,
                    )
                )

                await self._emit_event(
                    EventType.ATTEMPT_FAILED,
                    payload={
                        "attempt_number": attempt_number,
                        "duration_seconds": attempt_duration,
                        "error_type": exc.__class__.__name__,
                        "retryable": retryable,
                        **failure_metadata,
                    },
                )

                final_primary_failure = (not retryable) or attempt_number >= max_attempts

                if not final_primary_failure:
                    delay_seconds = await self._sleep_before_retry(
                        attempt_number,
                        retry_plan=retry_plan,
                    )

                    if retry_plan.rate_limited:
                        rate_limit_wait_seconds += delay_seconds

                    continue

                if self._fallback_chain is not None:
                    fallback_attempt_number = len(attempts) + 1
                    fallback_started_at = _utc_now()
                    fallback_started_monotonic = time.perf_counter()

                    await self._emit_event(
                        EventType.FALLBACK_STARTED,
                        payload={
                            "attempt_number": fallback_attempt_number,
                            "after_primary_attempts": len(attempts),
                        },
                    )

                    try:
                        fallback_result = await self._fallback_chain.run(*args, **kwargs)
                        fallback_validation_metadata = self._validate_value(fallback_result.value)
                    except Exception as fallback_exc:
                        fallback_duration = _elapsed_seconds(fallback_started_monotonic)
                        fallback_metadata = self._fallback_failure_metadata(fallback_exc)

                        if isinstance(fallback_exc, ValidationFailedError):
                            await self._emit_event(
                                EventType.VALIDATION_FAILED,
                                payload={
                                    "attempt_number": fallback_attempt_number,
                                    "validator_name": fallback_exc.validator_name,
                                    "reason": fallback_exc.reason,
                                    "fallback_used": True,
                                },
                            )

                        attempts.append(
                            ExecutionAttempt(
                                attempt_number=fallback_attempt_number,
                                status=self._attempt_status_for_exception(fallback_exc),
                                started_at=fallback_started_at,
                                duration_seconds=fallback_duration,
                                error=ExecutionError.from_exception(
                                    fallback_exc,
                                    retryable=False,
                                ),
                                metadata=fallback_metadata,
                            )
                        )

                        await self._emit_event(
                            EventType.FALLBACK_FAILED,
                            payload={
                                "attempt_number": fallback_attempt_number,
                                "duration_seconds": fallback_duration,
                                "error_type": fallback_exc.__class__.__name__,
                                **fallback_metadata,
                            },
                        )

                        await self._emit_event(
                            EventType.ATTEMPT_FAILED,
                            payload={
                                "attempt_number": fallback_attempt_number,
                                "duration_seconds": fallback_duration,
                                "error_type": fallback_exc.__class__.__name__,
                                "retryable": False,
                                **fallback_metadata,
                            },
                        )

                        rate_limit_summary_metadata = self._rate_limit_summary_metadata(
                            encountered=rate_limit_encountered,
                            wait_seconds=rate_limit_wait_seconds,
                            wait_exceeded=rate_limit_wait_exceeded,
                        )

                        report_metadata = self._merge_metadata(
                            fallback_metadata,
                            rate_limit_summary_metadata,
                        )

                        report = self._build_report(
                            status=self._report_status_for_attempt_status(attempts[-1].status),
                            started_at=operation_started_at,
                            started_monotonic=operation_started_monotonic,
                            attempts=attempts,
                            metadata=report_metadata,
                        )

                        await self._emit_event(
                            EventType.OPERATION_FAILED,
                            payload={
                                "duration_seconds": report.duration_seconds,
                                "attempt_count": report.attempt_count,
                                "retry_count": report.retry_count,
                                "error_type": fallback_exc.__class__.__name__,
                                **report_metadata,
                            },
                        )

                        raise OperationExecutionError(
                            f"Operation '{self.name}' failed and fallback chain failed.",
                            report=report,
                            cause=fallback_exc,
                        ) from fallback_exc

                    if fallback_validation_metadata["validation_performed"] is True:
                        await self._emit_event(
                            EventType.VALIDATION_SUCCEEDED,
                            payload={
                                "attempt_number": fallback_attempt_number,
                                "validator_name": fallback_validation_metadata[
                                    "validation_validator_name"
                                ],
                                "fallback_used": True,
                            },
                        )

                    fallback_metadata = self._fallback_success_metadata(
                        fallback_result,
                        validation_metadata=fallback_validation_metadata,
                    )
                    fallback_duration = _elapsed_seconds(fallback_started_monotonic)

                    attempts.append(
                        ExecutionAttempt(
                            attempt_number=fallback_attempt_number,
                            status=AttemptStatus.SUCCEEDED,
                            started_at=fallback_started_at,
                            duration_seconds=fallback_duration,
                            metadata=fallback_metadata,
                        )
                    )

                    await self._emit_event(
                        EventType.FALLBACK_SUCCEEDED,
                        payload={
                            "attempt_number": fallback_attempt_number,
                            "duration_seconds": fallback_duration,
                            **fallback_metadata,
                        },
                    )

                    await self._emit_event(
                        EventType.ATTEMPT_SUCCEEDED,
                        payload={
                            "attempt_number": fallback_attempt_number,
                            "duration_seconds": fallback_duration,
                            **fallback_metadata,
                        },
                    )

                    rate_limit_summary_metadata = self._rate_limit_summary_metadata(
                        encountered=rate_limit_encountered,
                        wait_seconds=rate_limit_wait_seconds,
                        wait_exceeded=rate_limit_wait_exceeded,
                    )

                    report_metadata = self._merge_metadata(
                        fallback_metadata,
                        rate_limit_summary_metadata,
                    )

                    report = self._build_report(
                        status=ExecutionStatus.SUCCEEDED,
                        started_at=operation_started_at,
                        started_monotonic=operation_started_monotonic,
                        attempts=attempts,
                        metadata=report_metadata,
                    )

                    await self._emit_event(
                        EventType.OPERATION_SUCCEEDED,
                        payload={
                            "duration_seconds": report.duration_seconds,
                            "attempt_count": report.attempt_count,
                            "retry_count": report.retry_count,
                            **report_metadata,
                        },
                    )

                    return OperationResult(
                        value=fallback_result.value,
                        report=report,
                    )

                rate_limit_summary_metadata = self._rate_limit_summary_metadata(
                    encountered=rate_limit_encountered,
                    wait_seconds=rate_limit_wait_seconds,
                    wait_exceeded=rate_limit_wait_exceeded,
                )

                report_metadata = self._merge_metadata(
                    failure_metadata,
                    rate_limit_summary_metadata,
                )

                report = self._build_report(
                    status=self._report_status_for_attempt_status(attempt_status),
                    started_at=operation_started_at,
                    started_monotonic=operation_started_monotonic,
                    attempts=attempts,
                    metadata=report_metadata,
                )

                await self._emit_event(
                    EventType.OPERATION_FAILED,
                    payload={
                        "duration_seconds": report.duration_seconds,
                        "attempt_count": report.attempt_count,
                        "retry_count": report.retry_count,
                        "error_type": exc.__class__.__name__,
                        **report_metadata,
                    },
                )

                raise OperationExecutionError(
                    f"Operation '{self.name}' failed after {len(attempts)} attempt(s).",
                    report=report,
                    cause=exc,
                ) from exc

            if validation_metadata["validation_performed"] is True:
                await self._emit_event(
                    EventType.VALIDATION_SUCCEEDED,
                    payload={
                        "attempt_number": attempt_number,
                        "validator_name": validation_metadata["validation_validator_name"],
                    },
                )

            attempt_duration = _elapsed_seconds(attempt_started_monotonic)
            success_metadata = self._primary_success_metadata(validation_metadata)

            attempts.append(
                ExecutionAttempt(
                    attempt_number=attempt_number,
                    status=AttemptStatus.SUCCEEDED,
                    started_at=attempt_started_at,
                    duration_seconds=attempt_duration,
                    metadata=success_metadata,
                )
            )

            await self._emit_event(
                EventType.ATTEMPT_SUCCEEDED,
                payload={
                    "attempt_number": attempt_number,
                    "duration_seconds": attempt_duration,
                    **success_metadata,
                },
            )

            rate_limit_summary_metadata = self._rate_limit_summary_metadata(
                encountered=rate_limit_encountered,
                wait_seconds=rate_limit_wait_seconds,
                wait_exceeded=rate_limit_wait_exceeded,
            )

            report_metadata = self._merge_metadata(
                success_metadata,
                rate_limit_summary_metadata,
            )

            report = self._build_report(
                status=ExecutionStatus.SUCCEEDED,
                started_at=operation_started_at,
                started_monotonic=operation_started_monotonic,
                attempts=attempts,
                metadata=report_metadata,
            )

            await self._emit_event(
                EventType.OPERATION_SUCCEEDED,
                payload={
                    "duration_seconds": report.duration_seconds,
                    "attempt_count": report.attempt_count,
                    "retry_count": report.retry_count,
                    **report_metadata,
                },
            )

            return OperationResult(value=value, report=report)

        raise RuntimeError("AsyncOperation reached an invalid execution state.")

    async def _run_single_attempt(
        self,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> tuple[R, MutableMetadata]:
        if self._circuit_breaker is not None:
            return await self._circuit_breaker.run_async(
                self._run_single_attempt_without_circuit_breaker,
                *args,
                **kwargs,
            )

        return await self._run_single_attempt_without_circuit_breaker(*args, **kwargs)

    async def _run_single_attempt_without_circuit_breaker(
        self,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> tuple[R, MutableMetadata]:
        if self._timeout_policy is None:
            value = await self._operation(*args, **kwargs)
        else:
            value = await self._timeout_policy.run_async(self._operation, *args, **kwargs)

        validation_metadata = self._validate_value(value)

        return value, validation_metadata

    def _validate_value(self, value: R) -> MutableMetadata:
        if self._validation_policy is None:
            return self._no_validation_metadata()

        result = self._validation_policy.validate(value)

        if result.valid:
            return self._validation_success_metadata(result)

        reason = result.reason or "Validation failed."

        raise ValidationFailedError(
            f"Validation failed in '{result.validator_name}': {reason}",
            validator_name=result.validator_name,
            reason=reason,
        )

    async def _sleep_before_retry(
        self,
        attempt_number: int,
        *,
        retry_plan: _RetryPlan,
    ) -> float:
        if self._retry_policy is None:
            raise RuntimeError("Retry sleep requested without retry policy.")

        if not retry_plan.retryable or retry_plan.delay_seconds is None:
            raise RuntimeError("Retry sleep requested without a retryable plan.")

        await self._emit_event(
            EventType.RETRY_SCHEDULED,
            payload={
                "attempt_number": attempt_number,
                "next_attempt_number": attempt_number + 1,
                "delay_seconds": retry_plan.delay_seconds,
                "delay_source": (
                    retry_plan.delay_source.value if retry_plan.delay_source is not None else None
                ),
                "rate_limited": retry_plan.rate_limited,
                "retry_after_seconds": retry_plan.retry_after_seconds,
            },
        )

        await self._retry_policy.async_sleeper(retry_plan.delay_seconds)

        return retry_plan.delay_seconds

    async def _emit_event(
        self,
        event_type: EventType,
        *,
        payload: Mapping[str, MetadataValue] | None = None,
    ) -> None:
        if self._event_emitter is None:
            return

        await self._event_emitter.emit(
            event_type,
            operation_name=self.name,
            payload=payload,
        )

    @staticmethod
    def _attempt_status_for_exception(exception: Exception) -> AttemptStatus:
        if isinstance(exception, OperationTimeoutError):
            return AttemptStatus.TIMED_OUT

        return AttemptStatus.FAILED

    @staticmethod
    def _report_status_for_attempt_status(status: AttemptStatus) -> ExecutionStatus:
        if status is AttemptStatus.TIMED_OUT:
            return ExecutionStatus.TIMED_OUT

        if status is AttemptStatus.CANCELLED:
            return ExecutionStatus.CANCELLED

        return ExecutionStatus.FAILED

    @staticmethod
    def _validation_success_metadata(result: ValidationResult) -> MutableMetadata:
        return {
            "validation_performed": True,
            "validation_valid": True,
            "validation_validator_name": result.validator_name,
            "validation_reason": None,
        }

    @staticmethod
    def _validation_failure_metadata(exception: ValidationFailedError) -> MutableMetadata:
        return {
            "validation_performed": True,
            "validation_valid": False,
            "validation_validator_name": exception.validator_name,
            "validation_reason": exception.reason,
        }

    @staticmethod
    def _no_validation_metadata() -> MutableMetadata:
        return {
            "validation_performed": False,
            "validation_valid": None,
            "validation_validator_name": None,
            "validation_reason": None,
        }

    def _base_metadata(self, validation_metadata: Metadata | None = None) -> MutableMetadata:
        metadata: MutableMetadata = {
            "fallback_used": False,
            "circuit_breaker_open": False,
        }

        if validation_metadata is None:
            metadata.update(self._no_validation_metadata())
        else:
            metadata.update(validation_metadata)

        return metadata

    def _primary_success_metadata(self, validation_metadata: Metadata) -> MutableMetadata:
        return self._base_metadata(validation_metadata)

    def _primary_failure_metadata(
        self,
        exception: Exception,
        *,
        retry_plan: _RetryPlan,
    ) -> MutableMetadata:
        metadata = self._base_metadata()

        metadata["circuit_breaker_open"] = isinstance(
            exception,
            CircuitBreakerOpenError,
        )

        if isinstance(exception, ValidationFailedError):
            metadata.update(self._validation_failure_metadata(exception))

        metadata.update(
            {
                "rate_limited": retry_plan.rate_limited,
                "rate_limit_retry_after_seconds": (retry_plan.retry_after_seconds),
                "rate_limit_delay_seconds": retry_plan.delay_seconds,
                "rate_limit_delay_source": (
                    retry_plan.delay_source.value if retry_plan.delay_source is not None else None
                ),
                "rate_limit_wait_exceeded": (retry_plan.max_wait_exceeded),
            }
        )

        return metadata

    @staticmethod
    def _fallback_success_metadata(
        result: FallbackResult[R],
        *,
        validation_metadata: Metadata,
    ) -> MutableMetadata:
        metadata: MutableMetadata = {
            "fallback_used": True,
            "fallback_failed": False,
            "fallback_candidate_name": result.candidate_name,
            "fallback_candidate_index": result.candidate_index,
            "fallback_failure_count": result.failure_count,
            "circuit_breaker_open": False,
        }
        metadata.update(validation_metadata)

        return metadata

    def _fallback_failure_metadata(self, exception: Exception) -> MutableMetadata:
        failure_count = len(exception.failures) if isinstance(exception, FallbackChainError) else 0

        metadata: MutableMetadata = {
            "fallback_used": True,
            "fallback_failed": True,
            "fallback_failure_count": failure_count,
            "circuit_breaker_open": isinstance(exception, CircuitBreakerOpenError),
        }

        if isinstance(exception, ValidationFailedError):
            metadata.update(self._validation_failure_metadata(exception))
        else:
            metadata.update(self._no_validation_metadata())

        return metadata

    @staticmethod
    def _operation_result_with_idempotency_metadata(
        idempotency_result: IdempotencyResult[OperationResult[R]],
    ) -> OperationResult[R]:
        operation_result = idempotency_result.value
        original_report = operation_result.report

        metadata: MutableMetadata = dict(original_report.metadata)
        metadata.update(
            {
                "idempotency_enabled": True,
                "idempotency_key": idempotency_result.key,
                "idempotency_status": idempotency_result.status.value,
                "idempotency_cache_hit": idempotency_result.cache_hit,
            }
        )

        report = ExecutionReport(
            operation_name=original_report.operation_name,
            status=original_report.status,
            started_at=original_report.started_at,
            duration_seconds=original_report.duration_seconds,
            attempts=original_report.attempts,
            metadata=metadata,
        )

        return OperationResult(
            value=operation_result.value,
            report=report,
        )

    def _retry_plan_for_exception(
        self,
        exception: Exception,
        *,
        attempt_number: int,
    ) -> _RetryPlan:
        rate_limit_decision = self._rate_limit_decision(exception)

        if rate_limit_decision.rate_limited:
            return self._rate_limit_retry_plan(
                rate_limit_decision,
                attempt_number=attempt_number,
            )

        if self._retry_policy is None:
            return _RetryPlan(retryable=False)

        if not isinstance(exception, self._retry_policy.retry_on):
            return _RetryPlan(retryable=False)

        delay_seconds = self._retry_policy.backoff.delay_for_retry(attempt_number)

        return _RetryPlan(
            retryable=True,
            delay_seconds=delay_seconds,
            delay_source=_RetryDelaySource.BACKOFF,
        )

    def _rate_limit_decision(
        self,
        exception: Exception,
    ) -> RateLimitDecision:
        if self._rate_limit_policy is None:
            return RateLimitDecision.not_rate_limited()

        return self._rate_limit_policy.evaluate(exception)

    def _rate_limit_retry_plan(
        self,
        decision: RateLimitDecision,
        *,
        attempt_number: int,
    ) -> _RetryPlan:
        if self._rate_limit_policy is None:
            raise RuntimeError("Rate-limit decision created without a rate-limit policy.")

        if self._retry_policy is None:
            return _RetryPlan(
                retryable=False,
                rate_limited=True,
                retry_after_seconds=decision.retry_after_seconds,
            )

        if decision.retry_after_seconds is not None:
            delay_seconds = decision.retry_after_seconds
            delay_source = _RetryDelaySource.PROVIDER
        else:
            delay_seconds = self._retry_policy.backoff.delay_for_retry(attempt_number)
            delay_source = _RetryDelaySource.BACKOFF

        if delay_seconds > self._rate_limit_policy.max_wait_seconds:
            return _RetryPlan(
                retryable=False,
                rate_limited=True,
                retry_after_seconds=decision.retry_after_seconds,
                max_wait_exceeded=True,
            )

        return _RetryPlan(
            retryable=True,
            rate_limited=True,
            retry_after_seconds=decision.retry_after_seconds,
            delay_seconds=delay_seconds,
            delay_source=delay_source,
        )

    @staticmethod
    def _rate_limit_summary_metadata(
        *,
        encountered: bool,
        wait_seconds: float,
        wait_exceeded: bool,
    ) -> MutableMetadata:
        return {
            "rate_limit_encountered": encountered,
            "rate_limit_wait_seconds": wait_seconds,
            "rate_limit_wait_exceeded": wait_exceeded,
        }

    @staticmethod
    def _merge_metadata(
        *items: Mapping[str, MetadataValue],
    ) -> MutableMetadata:
        metadata: MutableMetadata = {}

        for item in items:
            metadata.update(item)

        return metadata

    def _build_report(
        self,
        *,
        status: ExecutionStatus,
        started_at: datetime,
        started_monotonic: float,
        attempts: list[ExecutionAttempt],
        metadata: Metadata | None = None,
    ) -> ExecutionReport:
        return ExecutionReport(
            operation_name=self.name,
            status=status,
            started_at=started_at,
            duration_seconds=_elapsed_seconds(started_monotonic),
            attempts=tuple(attempts),
            metadata=metadata or {},
        )


def async_operation(
    name: str,
    operation: Callable[P, Awaitable[R]],
) -> AsyncOperation[P, R]:
    """Create a resilient wrapper for an asynchronous operation."""
    return AsyncOperation(name=name, _operation=operation)
